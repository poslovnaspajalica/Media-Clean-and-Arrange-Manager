(function ($) {
  function updateSelectedCount($gallery) {
    var count = $gallery.find(".mca-check:checked").length;
    $("#mca-selected-count").text(count);
  }

  function setTileSelected($tile, selected) {
    $tile.toggleClass("is-selected", !!selected);
  }

  function bindTileInteractions($gallery) {
    $gallery.off("change.mca", ".mca-check");
    $gallery.on("change.mca", ".mca-check", function () {
      var $cb = $(this);
      setTileSelected($cb.closest(".mca-tile"), $cb.is(":checked"));
      updateSelectedCount($gallery);
    });

    // Klik na tile: toggle selekciju (bez potrebe za checkboxom).
    // Bitno: .mca-tile-inner je <label>, pa moramo preventDefault da ne dođe do "double toggle".
    $gallery.off("click.mca", ".mca-tile-inner");
    $gallery.on("click.mca", ".mca-tile-inner", function (e) {
      if ($(e.target).is("a, button, select, textarea")) return;
      e.preventDefault();

      var $tile = $(this).closest(".mca-tile");
      var $cb = $tile.find(".mca-check");

      var isShift = !!e.shiftKey;
      var isToggle = !!(e.ctrlKey || e.metaKey);

      var $tiles = $gallery.find(".mca-tile");
      var idx = $tiles.index($tile);
      var last = $gallery.data("last-index");

      if (isShift && typeof last === "number" && last >= 0) {
        var start = Math.min(last, idx);
        var end = Math.max(last, idx);
        // Shift: označi range (ne diramo već označene izvan range-a)
        for (var i = start; i <= end; i++) {
          $tiles.eq(i).find(".mca-check").prop("checked", true);
        }
        $gallery.find(".mca-check").trigger("change");
      } else if (isToggle) {
        // Ctrl/Cmd: toggle samo ovu
        $cb.prop("checked", !$cb.is(":checked")).trigger("change");
      } else {
        // Bez modifikatora: toggle samo ovu (ne resetiramo ostale, da bude prirodno za bulk)
        $cb.prop("checked", !$cb.is(":checked")).trigger("change");
      }

      $gallery.data("last-index", idx);
    });
  }

  function loadMore($gallery) {
    if ($gallery.data("loading")) return;
    if ($gallery.data("has-more") !== 1 && $gallery.data("has-more") !== "1") return;

    $gallery.data("loading", true);
    $("#mca-loader").show();

    var ajaxUrl = $gallery.data("ajax-url");
    var nonce = $gallery.data("nonce");
    var page = parseInt($gallery.data("page"), 10) || 1;
    var perPage = parseInt($gallery.data("per-page"), 10) || 100;

    $.post(ajaxUrl, {
      action: "mca_gallery_load",
      nonce: nonce,
      page: page + 1,
      per_page: perPage,
      mode: $gallery.data("mode") || "date",
      start: $gallery.data("start") || "",
      end: $gallery.data("end") || "",
      month_start: $gallery.data("month-start") || "",
      month_end: $gallery.data("month-end") || "",
      s: $gallery.data("search") || "",
    })
      .done(function (res) {
        if (!res || !res.success) return;
        if (res.data && res.data.html) {
          $gallery.append(res.data.html);
        }
        $gallery.data("has-more", res.data && res.data.has_more ? 1 : 0);
        $gallery.data("page", res.data && res.data.next_page ? res.data.next_page - 1 : page + 1);
        bindTileInteractions($gallery);
      })
      .always(function () {
        $gallery.data("loading", false);
        $("#mca-loader").hide();
      });
  }

  function shouldLoadMore($gallery) {
    var scrollBottom = $(window).scrollTop() + $(window).height();
    var galleryBottom = $gallery.offset().top + $gallery.outerHeight();
    return scrollBottom + 600 >= galleryBottom; // prag
  }

  $(function () {
    var $gallery = $("#mca-gallery");
    var ajaxUrlFallback = window.ajaxurl || ($gallery.length ? $gallery.data("ajax-url") : null);
    var i18n = (window.MCA && window.MCA.i18n) ? window.MCA.i18n : {};
    var settings = (window.MCA && window.MCA.settings) ? window.MCA.settings : {};

    function maskRel(rel) {
      if (!settings.mask_paths) return rel || "";
      rel = String(rel || "");
      var base = rel.split("/").pop();
      return base ? ("…/" + base) : "…";
    }

    function breakGlassConfirm(message) {
      if (!settings.break_glass) {
        return confirm(message || "");
      }
      var phrase = (i18n.deletePhrase || "DELETE").trim().toUpperCase();
      var promptMsg = (message || "") + "\n\n" + (i18n.typeDeleteToConfirm || "Type DELETE to confirm:");
      var entered = window.prompt(promptMsg, "");
      if (entered === null) return false;
      return String(entered).trim().toUpperCase() === phrase;
    }

    if ($gallery.length) {
      bindTileInteractions($gallery);
      updateSelectedCount($gallery);

      $("#mca-select-all-loaded").on("click", function () {
        $gallery.find(".mca-check").prop("checked", true).trigger("change");
      });
      $("#mca-select-none").on("click", function () {
        $gallery.find(".mca-check").prop("checked", false).trigger("change");
      });

      $("#mca-bulk-form").on("submit", function () {
        var action = $("#mca_action").val();
        var count = $gallery.find(".mca-check:checked").length;
        $("#mca_confirm").val("");
      if (!action) {
        alert(i18n.pickBulkAction || "Select a bulk action.");
        return false;
      }
      if (count === 0) {
        alert(i18n.pickAtLeastOne || "Select at least one image.");
        return false;
      }
      if (action === "delete") {
        var ok = breakGlassConfirm(i18n.confirmPermanentDelete || "Permanent delete: original + all sizes will be removed. Continue?");
        if (ok) $("#mca_confirm").val(i18n.deletePhrase || "DELETE");
        return ok;
      }
      return true;
      });

      // Toggle UI-a za filter mode (date vs folder)
      $('input[name="mca_mode"]').on("change", function () {
        var mode = $(this).val();
        if (mode === "folder") {
          $(".mca-mode-date").hide();
          $(".mca-mode-folder").show();
        } else {
          $(".mca-mode-folder").hide();
          $(".mca-mode-date").show();
        }
      });

      $(window).on("scroll.mca", function () {
        if (shouldLoadMore($gallery)) {
          loadMore($gallery);
        }
      });
    }

    // Sync iz uploads
    var $syncBox = $(".mca-sync-box");
    var syncNonce = $syncBox.data("nonce");
    var $syncStatus = $("#mca_sync_status");
    var $syncResults = $("#mca_sync_results");
    var syncState = null; // { months:[], cursor:{}, include_resized:0/1 }

    function setStatus(txt) {
      $syncStatus.text(txt || "");
    }

    function renderSample(list) {
      if (!list || !list.length) {
        return "<p>" + (i18n.noMissingFound || "No missing files found in this batch.") + "</p>";
      }
      var html = '<div class="mca-preview-grid">';
      for (var i = 0; i < list.length; i++) {
        var rel = list[i].rel || "";
        var url = list[i].url || "";
        html += '<div class="mca-preview-item">';
        html += '<div class="mca-preview-thumb">';
        html += url ? ('<img loading="lazy" src="' + String(url).replace(/"/g, "&quot;") + '" alt="">') : "—";
        html += "</div>";
        html += '<div class="mca-preview-meta" title="' + String(maskRel(rel)).replace(/"/g, "&quot;") + '">';
        html += String(maskRel(rel)).replace(/</g, "&lt;");
        html += "</div>";
        html += '<div class="mca-preview-actions">';
        html += '<button type="button" class="button button-link-delete mca-preview-delete" data-rel="' + String(rel).replace(/"/g, "&quot;") + '">' + (i18n.deleteFile || "Delete file") + "</button>";
        html += "</div>";
        html += "</div>";
      }
      html += "</div>";
      return html;
    }

    $("#mca_sync_scan").on("click", function () {
      setStatus(i18n.scanning || "Scanning...");
      $("#mca_sync_import").prop("disabled", true);
      $syncResults.hide().empty();

      var mode = $('input[name="mca_sync_mode"]:checked').val() || "folder";
      var folder = ($("#mca_sync_folder").val() || "").trim();
      var includeResized = $("#mca_sync_include_resized").is(":checked") ? 1 : 0;

      // Range uzmi iz Sync boxa (ne ovisi o filterima gore)
      var monthStart = ($("#mca_sync_month_start").val() || "").trim();
      var monthEnd = ($("#mca_sync_month_end").val() || "").trim();

      if (mode === "folder" && !folder) {
        alert(i18n.enterFolderOrRange || "Enter a folder (YYYY/MM) or switch to range.");
        setStatus("");
        return;
      }
      if (mode === "range" && (!monthStart || !monthEnd)) {
        alert(i18n.pickRange || "Pick a YYYY-MM range.");
        setStatus("");
        return;
      }

      syncState = null;
      $.ajax({
        url: window.ajaxurl || ajaxUrlFallback,
        method: "POST",
        dataType: "json",
        data: {
          action: "mca_sync_scan",
          nonce: syncNonce,
          folder: mode === "folder" ? folder : "",
          month_start: mode === "range" ? monthStart : "",
          month_end: mode === "range" ? monthEnd : "",
          include_resized: includeResized,
        },
      })
        .done(function (res) {
          if (!res || !res.success) {
            setStatus((res && res.data && res.data.message) || (i18n.scanError || "Scan error."));
            return;
          }
          syncState = {
            months: res.data.months,
            scan_id: res.data.scan_id,
            include_resized: includeResized,
            items: res.data.items || [],
            offset: 0,
          };
          setStatus((i18n.scanOk || "Scan OK.") + " " + (i18n.totalFound || "Total found:") + " " + (res.data.total || syncState.items.length) + (res.data.truncated ? (" " + (i18n.truncated || "(truncated)")) : ""));
          $syncResults.html(renderSample(syncState.items)).show();
          $("#mca_sync_import").prop("disabled", false);
        })
        .fail(function (xhr, status) {
          var msg = "Greška kod skeniranja (AJAX): " + (status || "unknown");
          if (xhr && xhr.status) msg += " HTTP " + xhr.status;
          if (xhr && xhr.responseText) {
            msg += " | " + String(xhr.responseText).slice(0, 180);
          }
          setStatus(msg);
        });
    });

    // Delete a file from uploads directly from Sync preview
    $(document).on("click", ".mca-preview-delete", function () {
      if (!syncState) return;
      var rel = $(this).data("rel");
      if (!rel) return;
      if (!breakGlassConfirm(i18n.confirmDeleteFile || "Delete this file from uploads?")) return;
      var $btn = $(this);
      $btn.prop("disabled", true).text(i18n.deleting || "Deleting...");
      $.ajax({
        url: window.ajaxurl || ajaxUrlFallback,
        method: "POST",
        dataType: "json",
        data: {
          action: "mca_sync_delete_file",
          nonce: syncNonce,
          scan_id: syncState.scan_id,
          confirm: (i18n.deletePhrase || "DELETE"),
          rel: rel,
        },
      })
        .done(function (res) {
          if (!res || !res.success) {
            alert((res && res.data && res.data.message) || "Error");
            $btn.prop("disabled", false).text(i18n.deleteFile || "Delete file");
            return;
          }
          // remove from state + rerender
          syncState.items = (syncState.items || []).filter(function (it) {
            return it.rel !== rel;
          });
          $syncResults.html(renderSample(syncState.items)).show();
          setStatus((i18n.totalFound || "Total found:") + " " + syncState.items.length);
        })
        .fail(function () {
          $btn.prop("disabled", false).text(i18n.deleteFile || "Delete file");
        });
    });

    $("#mca_sync_import").on("click", function () {
      if (!syncState || !syncState.months || !syncState.months.length) {
        alert(i18n.runScanFirst || "Run the scan first.");
        return;
      }
      if (!breakGlassConfirm(i18n.confirmImport || "This will import missing ORIGINAL files into the Media Library. Continue?")) {
        return;
      }

      var totalImported = 0;
      setStatus(i18n.importing || "Importing...");
      $("#mca_sync_import").prop("disabled", true);

      function step() {
        $.ajax({
          url: window.ajaxurl || ajaxUrlFallback,
          method: "POST",
          dataType: "json",
          data: {
            action: "mca_sync_import",
            nonce: syncNonce,
            scan_id: syncState.scan_id,
            confirm: (i18n.deletePhrase || "DELETE"),
            offset: syncState.offset || 0,
          },
        })
          .done(function (res) {
            if (!res || !res.success) {
              setStatus((res && res.data && res.data.message) || (i18n.importError || "Import error."));
              $("#mca_sync_import").prop("disabled", false);
              return;
            }
            totalImported += res.data.imported || 0;
            syncState.offset = res.data.next_offset || 0;
            setStatus((i18n.imported || "Imported:") + " " + totalImported + " | " + (i18n.skipped || "Skipped:") + " " + (res.data.skipped || 0) + (res.data.done ? (" " + (i18n.done || "(done)")) : (" " + (i18n.continue || "(continuing...)"))));
            if (res.data.done) {
              $syncResults.prepend("<p><strong>" + (i18n.importFinished || "Import finished.") + " " + (i18n.totalImported || "Total imported:") + " " + totalImported + ".</strong> " + (i18n.refreshToSee || "Refresh the page to see new items.") + "</p>");
              $("#mca_sync_import").prop("disabled", false);
              return;
            }
            // loop
            setTimeout(step, 250);
          })
          .fail(function (xhr, status) {
            var msg = "Greška kod uvoza (AJAX): " + (status || "unknown");
            if (xhr && xhr.status) msg += " HTTP " + xhr.status;
            if (xhr && xhr.responseText) {
              msg += " | " + String(xhr.responseText).slice(0, 180);
            }
            setStatus(msg);
            $("#mca_sync_import").prop("disabled", false);
          });
      }

      step();
    });

    // Cleanup resized
    var $cleanupBox = $(".mca-cleanup-box");
    var cleanupNonce = $cleanupBox.data("nonce");
    var $cleanupStatus = $("#mca_cleanup_status");
    var $cleanupResults = $("#mca_cleanup_results");
    var cleanupState = null; // { months:[], cursor:{}, delete_orphan:1/0 }

    function setCleanupStatus(txt) {
      $cleanupStatus.text(txt || "");
    }

    function renderCleanupSample(list) {
      if (!list || !list.length) {
        return "<p>" + (i18n.noResizedFound || "No resized files found in this batch.") + "</p>";
      }
      var html = '<div class="mca-preview-grid">';
      for (var i = 0; i < list.length; i++) {
        var rel = list[i].rel || "";
        var url = list[i].url || "";
        html += '<div class="mca-preview-item">';
        html += '<div class="mca-preview-thumb">';
        html += url ? ('<img loading="lazy" src="' + String(url).replace(/"/g, "&quot;") + '" alt="">') : "—";
        html += "</div>";
        html += '<div class="mca-preview-meta" title="' + String(maskRel(rel)).replace(/"/g, "&quot;") + '">';
        html += String(maskRel(rel)).replace(/</g, "&lt;");
        html += "</div>";
        html += "</div>";
      }
      html += "</div>";
      return html;
    }

    $("#mca_cleanup_scan").on("click", function () {
      setCleanupStatus(i18n.scanning || "Scanning...");
      $("#mca_cleanup_delete").prop("disabled", true);
      $cleanupResults.hide().empty();

      var mode = $('input[name="mca_cleanup_mode"]:checked').val() || "folder";
      var folder = ($("#mca_cleanup_folder").val() || "").trim();
      var monthStart = ($("#mca_cleanup_month_start").val() || "").trim();
      var monthEnd = ($("#mca_cleanup_month_end").val() || "").trim();
      var onlyOrphan = $("#mca_cleanup_only_orphan").is(":checked") ? 1 : 0;

      if (mode === "folder" && !folder) {
        alert("Upiši folder u formatu YYYY/MM (npr. 2017/02) ili prebaci na range.");
        setCleanupStatus("");
        return;
      }
      if (mode === "range" && (!monthStart || !monthEnd)) {
        alert("Odaberi range od/do (YYYY-MM).");
        setCleanupStatus("");
        return;
      }

      $.ajax({
        url: window.ajaxurl || ajaxUrlFallback,
        method: "POST",
        dataType: "json",
        data: {
          action: "mca_resized_scan",
          nonce: cleanupNonce,
          folder: mode === "folder" ? folder : "",
          month_start: mode === "range" ? monthStart : "",
          month_end: mode === "range" ? monthEnd : "",
          only_orphan: onlyOrphan,
        },
      })
        .done(function (res) {
          if (!res || !res.success) {
            setCleanupStatus((res && res.data && res.data.message) || "Greška kod skeniranja.");
            return;
          }
          cleanupState = {
            months: res.data.months,
            scan_id: res.data.scan_id,
            only_orphan: res.data.only_orphan ? 1 : 0,
            items: res.data.items || [],
            offset: 0,
          };
          setCleanupStatus((i18n.scanOk || "Scan OK.") + " " + (i18n.totalFound || "Total found:") + " " + (res.data.total || cleanupState.items.length) + (res.data.truncated ? (" " + (i18n.truncated || "(truncated)")) : ""));
          $cleanupResults.html(renderCleanupSample(cleanupState.items)).show();
          $("#mca_cleanup_delete").prop("disabled", false);
        })
        .fail(function (xhr, status) {
          var msg = "Greška (AJAX): " + (status || "unknown");
          if (xhr && xhr.status) msg += " HTTP " + xhr.status;
          if (xhr && xhr.responseText) msg += " | " + String(xhr.responseText).slice(0, 180);
          setCleanupStatus(msg);
        });
    });

    $("#mca_cleanup_delete").on("click", function () {
      if (!cleanupState || !cleanupState.months || !cleanupState.months.length) {
        alert(i18n.runScanFirst || "Run the scan first.");
        return;
      }
      if (!breakGlassConfirm(i18n.confirmDeleteResized || "This will delete resized files (-WxH). Originals will not be touched. Continue?")) {
        return;
      }

      var totalDeleted = 0;
      var totalSkipped = 0;
      setCleanupStatus(i18n.deleting || "Deleting...");
      $("#mca_cleanup_delete").prop("disabled", true);

      function stepDel() {
        $.ajax({
          url: window.ajaxurl || ajaxUrlFallback,
          method: "POST",
          dataType: "json",
          data: {
            action: "mca_resized_delete",
            nonce: cleanupNonce,
            scan_id: cleanupState.scan_id,
            confirm: (i18n.deletePhrase || "DELETE"),
            offset: cleanupState.offset || 0,
          },
        })
          .done(function (res) {
            if (!res || !res.success) {
              setCleanupStatus((res && res.data && res.data.message) || "Greška kod brisanja.");
              $("#mca_cleanup_delete").prop("disabled", false);
              return;
            }
            totalDeleted += res.data.deleted || 0;
            totalSkipped += res.data.skipped || 0;
            cleanupState.offset = res.data.next_offset || 0;
            setCleanupStatus("Obrisano: " + totalDeleted + " | preskočeno: " + totalSkipped + (res.data.done ? " (gotovo)" : " (nastavljam...)"));
            if (res.data.done) {
              $cleanupResults.prepend("<p><strong>Čišćenje završeno.</strong> Obrisano: " + totalDeleted + ", preskočeno: " + totalSkipped + ".</p>");
              $("#mca_cleanup_delete").prop("disabled", false);
              return;
            }
            setTimeout(stepDel, 200);
          })
          .fail(function (xhr, status) {
            var msg = "Greška (AJAX): " + (status || "unknown");
            if (xhr && xhr.status) msg += " HTTP " + xhr.status;
            if (xhr && xhr.responseText) msg += " | " + String(xhr.responseText).slice(0, 180);
            setCleanupStatus(msg);
            $("#mca_cleanup_delete").prop("disabled", false);
          });
      }

      stepDel();
    });
  });
})(jQuery);


