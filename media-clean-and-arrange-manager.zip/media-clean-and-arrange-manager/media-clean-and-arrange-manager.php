<?php
/**
 * Plugin Name: Media Clean and Arrange Manager
 * Plugin URI: https://github.com/poslovnaspajalica/Media-Clean-and-Arrange-Manager
 * Description: Manage and clean WordPress Media Library: gallery view with bulk actions, sync missing files from uploads into the Media Library, and safely remove orphan resized images. Built for migrations and messy uploads.
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: BusinessClip Ltd
 * Author URI: https://poslovnaspajalica.hr
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: media-clean-and-arrange-manager
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

final class MCA_Media_Clean_Arrange_Manager {
    const VERSION = '1.0.0';
    const SLUG = 'media-clean-and-arrange-manager';
    const TEXT_DOMAIN = 'media-clean-and-arrange-manager';
    // Temporary: Donations tab disabled (can be re-enabled in a future release).
    const ENABLE_DONATE_TAB = false;
    /**
     * Security posture: restrict this tool to site admins.
     * (Defense-in-depth: scans expose file paths and destructive actions modify filesystem.)
     */
    const CAPABILITY = 'manage_options';
    const OPT_AUDIT_ENABLED = 'mca_audit_enabled';
    const OPT_RATE_LIMIT_ENABLED = 'mca_rate_limit_enabled';
    const OPT_RATE_LIMIT_SECONDS = 'mca_rate_limit_seconds';
    const OPT_AUDIT_LOG = 'mca_audit_log';
    const OPT_AUDIT_FILE_ENABLED = 'mca_audit_file_enabled';
    const OPT_AUDIT_WPLOG_ENABLED = 'mca_audit_wplog_enabled';
    const OPT_MASK_PATHS = 'mca_mask_paths';
    const OPT_BREAK_GLASS_ENABLED = 'mca_break_glass_enabled';

    const NONCE_ACTION = 'mca_bulk_action';
    const NONCE_NAME = 'mca_nonce';

    const AJAX_NONCE_ACTION = 'mca_gallery_load';
    const SYNC_NONCE_ACTION = 'mca_sync_uploads';
    const CLEANUP_NONCE_ACTION = 'mca_cleanup_resized';
    const SCAN_TTL_SECONDS = 1800; // 30 min
    const AUDIT_MAX_ENTRIES = 200;
    const AUDIT_FILE_MAX_BYTES = 2097152; // 2 MB

    public static function init(): void {
        if (!is_admin()) {
            return;
        }

        add_action('init', [__CLASS__, 'load_textdomain']);
        add_action('admin_menu', [__CLASS__, 'admin_menu']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'admin_enqueue']);

        add_action('admin_post_mca_bulk', [__CLASS__, 'handle_bulk_action']);
        add_action('admin_post_mca_security_save', [__CLASS__, 'handle_security_save']);
        add_action('admin_post_mca_audit_clear', [__CLASS__, 'handle_audit_clear']);

        add_action('wp_ajax_mca_gallery_load', [__CLASS__, 'ajax_gallery_load']);
        add_action('wp_ajax_mca_sync_scan', [__CLASS__, 'ajax_sync_scan']);
        add_action('wp_ajax_mca_sync_import', [__CLASS__, 'ajax_sync_import']);
        add_action('wp_ajax_mca_sync_delete_file', [__CLASS__, 'ajax_sync_delete_file']);
        add_action('wp_ajax_mca_resized_scan', [__CLASS__, 'ajax_resized_scan']);
        add_action('wp_ajax_mca_resized_delete', [__CLASS__, 'ajax_resized_delete']);
    }

    public static function load_textdomain(): void {
        // WordPress.org will auto-load translations from language packs.
        // For local/dev installs, load bundled .mo if present.
        $domain = 'media-clean-and-arrange-manager';
        $locale = function_exists('determine_locale') ? determine_locale() : get_locale();
        $base = plugin_dir_path(__FILE__) . 'languages/';

        $candidates = [
            $base . $domain . '-' . $locale . '.mo',
            $base . $domain . '-' . strtolower(str_replace('-', '_', $locale)) . '.mo',
        ];
        // Fallback: also try language-only (e.g. hr)
        $lang_only = preg_replace('/^([a-z]{2,3}).*$/i', '$1', (string) $locale);
        if (is_string($lang_only) && $lang_only !== '' && $lang_only !== $locale) {
            $candidates[] = $base . $domain . '-' . $lang_only . '.mo';
        }

        foreach ($candidates as $mofile) {
            if (is_string($mofile) && file_exists($mofile)) {
                load_textdomain($domain, $mofile);
                break;
            }
        }
    }

    public static function admin_menu(): void {
        add_menu_page(
            __('Media Clean & Arrange', 'media-clean-and-arrange-manager'),
            __('Media Clean & Arrange', 'media-clean-and-arrange-manager'),
            self::CAPABILITY,
            self::SLUG,
            [__CLASS__, 'render_page'],
            'dashicons-images-alt2',
            58
        );
    }

    public static function admin_enqueue(string $hook): void {
        if ($hook !== 'toplevel_page_' . self::SLUG) {
            return;
        }

        $base = plugin_dir_url(__FILE__);
        wp_enqueue_style('mca-admin', $base . 'assets/admin.css', [], self::VERSION);
        wp_enqueue_script('mca-admin', $base . 'assets/admin.js', ['jquery'], self::VERSION, true);

        // Localized strings for JS (translation-ready)
        wp_localize_script('mca-admin', 'MCA', [
            'i18n' => [
                'pickBulkAction' => __('Select a bulk action.', 'media-clean-and-arrange-manager'),
                'pickAtLeastOne' => __('Select at least one image.', 'media-clean-and-arrange-manager'),
                'confirmPermanentDelete' => __('Permanent delete: original + all sizes will be removed. Continue?', 'media-clean-and-arrange-manager'),
                'scanning' => __('Scanning...', 'media-clean-and-arrange-manager'),
                'scanOk' => __('Scan OK.', 'media-clean-and-arrange-manager'),
                'foldersPlanned' => __('Folders planned:', 'media-clean-and-arrange-manager'),
                'scanError' => __('Scan error.', 'media-clean-and-arrange-manager'),
                'runScanFirst' => __('Run the scan first.', 'media-clean-and-arrange-manager'),
                'pickRange' => __('Pick a YYYY-MM range.', 'media-clean-and-arrange-manager'),
                'enterFolderOrRange' => __('Enter a folder (YYYY/MM) or switch to range.', 'media-clean-and-arrange-manager'),
                'confirmImport' => __('This will import missing ORIGINAL files into the Media Library. Continue?', 'media-clean-and-arrange-manager'),
                'importing' => __('Importing...', 'media-clean-and-arrange-manager'),
                'importError' => __('Import error.', 'media-clean-and-arrange-manager'),
                'imported' => __('Imported:', 'media-clean-and-arrange-manager'),
                'done' => __('(done)', 'media-clean-and-arrange-manager'),
                'continue' => __('(continuing...)', 'media-clean-and-arrange-manager'),
                'importFinished' => __('Import finished.', 'media-clean-and-arrange-manager'),
                'totalImported' => __('Total imported:', 'media-clean-and-arrange-manager'),
                'refreshToSee' => __('Refresh the page to see new items.', 'media-clean-and-arrange-manager'),
                'confirmDeleteResized' => __('This will delete resized files (-WxH). Originals will not be touched. Continue?', 'media-clean-and-arrange-manager'),
                'deleting' => __('Deleting...', 'media-clean-and-arrange-manager'),
                'loadMore' => __('Load more previews', 'media-clean-and-arrange-manager'),
                'loading' => __('Loading...', 'media-clean-and-arrange-manager'),
                'noMissingFound' => __('No missing files found in this batch.', 'media-clean-and-arrange-manager'),
                'noResizedFound' => __('No resized files found in this batch.', 'media-clean-and-arrange-manager'),
                'totalFound' => __('Total found:', 'media-clean-and-arrange-manager'),
                'truncated' => __('(truncated)', 'media-clean-and-arrange-manager'),
                'deleteFile' => __('Delete file', 'media-clean-and-arrange-manager'),
                'confirmDeleteFile' => __('Delete this file from uploads?', 'media-clean-and-arrange-manager'),
                'skipped' => __('Skipped:', 'media-clean-and-arrange-manager'),
                'typeDeleteToConfirm' => __('Type DELETE to confirm:', 'media-clean-and-arrange-manager'),
                'deletePhrase' => __('DELETE', 'media-clean-and-arrange-manager'),
            ],
            'settings' => [
                'break_glass' => self::is_break_glass_enabled() ? 1 : 0,
                'mask_paths' => self::is_mask_paths_enabled() ? 1 : 0,
            ],
        ]);
    }

    public static function render_page(): void {
        if (!current_user_can(self::CAPABILITY)) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'media-clean-and-arrange-manager'));
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        $tab = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'gallery';
        $allowed_tabs = ['gallery', 'sync', 'cleanup', 'help'];
        if (self::ENABLE_DONATE_TAB) {
            $allowed_tabs[] = 'donate';
        }
        $tab = in_array($tab, $allowed_tabs, true) ? $tab : 'gallery';

        $message = '';
        if (!empty($_GET['mca_msg'])) {
            $message = sanitize_text_field(wp_unslash($_GET['mca_msg']));
        }

        // Gallery filters
        $mode = isset($_GET['mca_mode']) ? sanitize_key(wp_unslash($_GET['mca_mode'])) : 'date';
        $mode = in_array($mode, ['date', 'folder'], true) ? $mode : 'date';

        $start = isset($_GET['mca_start']) ? sanitize_text_field(wp_unslash($_GET['mca_start'])) : '';
        $end = isset($_GET['mca_end']) ? sanitize_text_field(wp_unslash($_GET['mca_end'])) : '';

        $month_start = isset($_GET['mca_month_start']) ? sanitize_text_field(wp_unslash($_GET['mca_month_start'])) : '';
        $month_end = isset($_GET['mca_month_end']) ? sanitize_text_field(wp_unslash($_GET['mca_month_end'])) : '';

        $s = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        $per_page = 100;
        $page = 1;

        $initial = self::query_attachments([
            'per_page' => $per_page,
            'page' => $page,
            'mode' => $mode,
            'start' => $start,
            'end' => $end,
            'month_start' => $month_start,
            'month_end' => $month_end,
            's' => $s,
        ]);

        $ajax_nonce = wp_create_nonce(self::AJAX_NONCE_ACTION);
        $sync_nonce = wp_create_nonce(self::SYNC_NONCE_ACTION);
        $cleanup_nonce = wp_create_nonce(self::CLEANUP_NONCE_ACTION);
        $logo_url = plugins_url('assets/logo.png', __FILE__);
        $audit_enabled = self::is_audit_enabled();
        $rate_enabled = self::is_rate_limit_enabled();
        $rate_seconds = self::rate_limit_seconds();
        $audit_log = self::get_audit_log();

        ?>
        <div class="wrap mca-wrap">
            <div class="mca-header">
                <div class="mca-header-left">
                    <h1 class="mca-title"><?php echo esc_html__('Media Clean and Arrange Manager', 'media-clean-and-arrange-manager'); ?></h1>
                    <p class="mca-subtitle">
                        <?php echo esc_html__('A toolbox for cleaning, syncing and bulk-managing images in your WordPress Media Library.', 'media-clean-and-arrange-manager'); ?>
                    </p>
                </div>
                <div class="mca-header-right">
                    <img class="mca-logo" src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr__('Media Clean and Arrange Manager', 'media-clean-and-arrange-manager'); ?>">
                </div>
            </div>

            <?php if ($message !== '') : ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html($message); ?></p></div>
            <?php endif; ?>

            <h2 class="nav-tab-wrapper">
                <a class="nav-tab <?php echo $tab === 'gallery' ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url(self::admin_url(['tab' => 'gallery'])); ?>">
                    <?php echo esc_html__('Gallery', 'media-clean-and-arrange-manager'); ?>
                </a>
                <a class="nav-tab <?php echo $tab === 'sync' ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url(self::admin_url(['tab' => 'sync'])); ?>">
                    <?php echo esc_html__('Sync from uploads', 'media-clean-and-arrange-manager'); ?>
                </a>
                <a class="nav-tab <?php echo $tab === 'cleanup' ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url(self::admin_url(['tab' => 'cleanup'])); ?>">
                    <?php echo esc_html__('Cleanup resized', 'media-clean-and-arrange-manager'); ?>
                </a>
                <a class="nav-tab mca-nav-tab-security <?php echo $tab === 'help' ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url(self::admin_url(['tab' => 'help'])); ?>">
                    <?php echo esc_html__('Security settings', 'media-clean-and-arrange-manager'); ?>
                </a>
                <?php if (self::ENABLE_DONATE_TAB) : ?>
                    <a class="nav-tab <?php echo $tab === 'donate' ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url(self::admin_url(['tab' => 'donate'])); ?>">
                        <?php echo esc_html__('Donations', 'media-clean-and-arrange-manager'); ?>
                    </a>
                <?php endif; ?>
            </h2>

            <?php if ($tab === 'gallery') : ?>
                <div class="mca-card">
                    <h2><?php echo esc_html__('Filters', 'media-clean-and-arrange-manager'); ?></h2>
                    <form method="get" class="mca-filters">
                        <input type="hidden" name="page" value="<?php echo esc_attr(self::SLUG); ?>">
                        <input type="hidden" name="tab" value="gallery">

                        <div class="mca-mode">
                            <label>
                                <input type="radio" name="mca_mode" value="date" <?php checked($mode, 'date'); ?>>
                                <?php echo esc_html__('Filter by upload date', 'media-clean-and-arrange-manager'); ?>
                            </label>
                            <label>
                                <input type="radio" name="mca_mode" value="folder" <?php checked($mode, 'folder'); ?>>
                                <?php echo esc_html__('Filter by folders (YYYY/MM)', 'media-clean-and-arrange-manager'); ?>
                            </label>
                        </div>

                        <div class="mca-mode-date" style="<?php echo $mode === 'date' ? '' : 'display:none;'; ?>">
                            <label>
                                <span><?php echo esc_html__('Start date', 'media-clean-and-arrange-manager'); ?></span>
                                <input type="date" name="mca_start" value="<?php echo esc_attr($start); ?>">
                            </label>
                            <label>
                                <span><?php echo esc_html__('End date', 'media-clean-and-arrange-manager'); ?></span>
                                <input type="date" name="mca_end" value="<?php echo esc_attr($end); ?>">
                            </label>
                        </div>

                        <div class="mca-mode-folder" style="<?php echo $mode === 'folder' ? '' : 'display:none;'; ?>">
                            <label>
                                <span><?php echo esc_html__('Folder range start (YYYY-MM)', 'media-clean-and-arrange-manager'); ?></span>
                                <input type="month" name="mca_month_start" value="<?php echo esc_attr($month_start); ?>">
                            </label>
                            <label>
                                <span><?php echo esc_html__('Folder range end (YYYY-MM)', 'media-clean-and-arrange-manager'); ?></span>
                                <input type="month" name="mca_month_end" value="<?php echo esc_attr($month_end); ?>">
                            </label>
                        </div>

                        <label class="mca-search">
                            <span><?php echo esc_html__('Search', 'media-clean-and-arrange-manager'); ?></span>
                            <input type="search" name="s" value="<?php echo esc_attr($s); ?>" placeholder="<?php echo esc_attr__('Title / file…', 'media-clean-and-arrange-manager'); ?>">
                        </label>

                        <button class="button button-secondary" type="submit"><?php echo esc_html__('Apply filters', 'media-clean-and-arrange-manager'); ?></button>
                    </form>
                </div>

                <div class="mca-card">
                    <h2><?php echo esc_html__('Bulk actions', 'media-clean-and-arrange-manager'); ?></h2>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="mca-bulk-form">
                        <input type="hidden" name="action" value="mca_bulk">
                        <input type="hidden" name="mca_confirm" id="mca_confirm" value="">
                        <?php wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME); ?>

                        <div class="mca-toolbar">
                            <div class="mca-toolbar-left">
                                <button type="button" class="button" id="mca-select-all-loaded"><?php echo esc_html__('Select all loaded', 'media-clean-and-arrange-manager'); ?></button>
                                <button type="button" class="button" id="mca-select-none"><?php echo esc_html__('Clear selection', 'media-clean-and-arrange-manager'); ?></button>
                                <span class="mca-selected-count"><?php echo esc_html__('Selected:', 'media-clean-and-arrange-manager'); ?> <strong id="mca-selected-count">0</strong></span>
                            </div>
                            <div class="mca-toolbar-right">
                                <select name="mca_action" id="mca_action" required>
                                    <option value=""><?php echo esc_html__('— Bulk action —', 'media-clean-and-arrange-manager'); ?></option>
                                    <option value="trash"><?php echo esc_html__('Move to Trash', 'media-clean-and-arrange-manager'); ?></option>
                                    <option value="restore"><?php echo esc_html__('Restore from Trash', 'media-clean-and-arrange-manager'); ?></option>
                                    <option value="detach"><?php echo esc_html__('Detach from content', 'media-clean-and-arrange-manager'); ?></option>
                                    <option value="delete"><?php echo esc_html__('Delete permanently', 'media-clean-and-arrange-manager'); ?></option>
                                </select>
                                <button type="submit" class="button button-primary"><?php echo esc_html__('Apply', 'media-clean-and-arrange-manager'); ?></button>
                            </div>
                        </div>

                        <div
                            id="mca-gallery"
                            class="mca-gallery"
                            data-ajax-url="<?php echo esc_attr(admin_url('admin-ajax.php')); ?>"
                            data-nonce="<?php echo esc_attr($ajax_nonce); ?>"
                            data-per-page="<?php echo (int) $per_page; ?>"
                            data-page="<?php echo (int) $page; ?>"
                            data-has-more="<?php echo $initial['has_more'] ? '1' : '0'; ?>"
                            data-mode="<?php echo esc_attr($mode); ?>"
                            data-start="<?php echo esc_attr($start); ?>"
                            data-end="<?php echo esc_attr($end); ?>"
                            data-month-start="<?php echo esc_attr($month_start); ?>"
                            data-month-end="<?php echo esc_attr($month_end); ?>"
                            data-search="<?php echo esc_attr($s); ?>"
                        >
                            <?php echo self::render_gallery_items_html($initial['items']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        </div>

                        <div class="mca-loader" id="mca-loader" style="display:none;">
                            <?php echo esc_html__('Loading more images…', 'media-clean-and-arrange-manager'); ?>
                        </div>
                    </form>
                </div>
            <?php endif; ?>

            <?php if ($tab === 'sync') : ?>
                <div class="mca-card">
                    <h2><?php echo esc_html__('Sync files from uploads', 'media-clean-and-arrange-manager'); ?></h2>
                    <div class="mca-sync-box" data-nonce="<?php echo esc_attr($sync_nonce); ?>">
                        <p>
                            <?php echo esc_html__('If images exist in wp-content/uploads but are missing from the Media Library, they are not registered as attachments in the database.', 'media-clean-and-arrange-manager'); ?>
                            <?php echo esc_html__('This tool scans the filesystem and imports missing originals into the Media Library.', 'media-clean-and-arrange-manager'); ?>
                        </p>

                        <div class="mca-sync-grid">
                            <div class="mca-sync-mode">
                                <label><input type="radio" name="mca_sync_mode" value="folder" checked> <?php echo esc_html__('Scan one folder', 'media-clean-and-arrange-manager'); ?></label>
                                <label><input type="radio" name="mca_sync_mode" value="range"> <?php echo esc_html__('Scan folder range', 'media-clean-and-arrange-manager'); ?></label>
                            </div>

                            <label>
                                <span><?php echo esc_html__('Folder (YYYY/MM)', 'media-clean-and-arrange-manager'); ?></span>
                                <input type="text" id="mca_sync_folder">
                            </label>
                            <label>
                                <span><?php echo esc_html__('Range start (YYYY-MM)', 'media-clean-and-arrange-manager'); ?></span>
                                <input type="month" id="mca_sync_month_start" value="<?php echo esc_attr($month_start); ?>">
                            </label>
                            <label>
                                <span><?php echo esc_html__('Range end (YYYY-MM)', 'media-clean-and-arrange-manager'); ?></span>
                                <input type="month" id="mca_sync_month_end" value="<?php echo esc_attr($month_end); ?>">
                            </label>

                            <label class="mca-sync-checkbox">
                                <input type="checkbox" id="mca_sync_include_resized" value="1">
                                <?php echo esc_html__('Include resized files (-150x150). Not recommended.', 'media-clean-and-arrange-manager'); ?>
                            </label>
                        </div>

                        <div class="mca-sync-actions">
                            <button type="button" class="button" id="mca_sync_scan"><?php echo esc_html__('Scan', 'media-clean-and-arrange-manager'); ?></button>
                            <button type="button" class="button button-primary" id="mca_sync_import" disabled><?php echo esc_html__('Import missing (batch)', 'media-clean-and-arrange-manager'); ?></button>
                            <span class="mca-sync-status" id="mca_sync_status"></span>
                        </div>
                        <div class="mca-sync-results" id="mca_sync_results" style="display:none;"></div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($tab === 'cleanup') : ?>
                <div class="mca-card">
                    <h2><?php echo esc_html__('Cleanup orphan resized images', 'media-clean-and-arrange-manager'); ?></h2>
                    <div class="mca-cleanup-box" data-nonce="<?php echo esc_attr($cleanup_nonce); ?>">
                        <p>
                            <?php echo esc_html__('Deletes resized variants (-WxH) only when the original image is missing.', 'media-clean-and-arrange-manager'); ?>
                            <?php echo esc_html__('Original detection includes -scaled/-rotated variants and common image extensions.', 'media-clean-and-arrange-manager'); ?>
                        </p>

                        <div class="mca-cleanup-grid">
                            <div class="mca-cleanup-mode">
                                <label><input type="radio" name="mca_cleanup_mode" value="folder" checked> <?php echo esc_html__('Clean one folder', 'media-clean-and-arrange-manager'); ?></label>
                                <label><input type="radio" name="mca_cleanup_mode" value="range"> <?php echo esc_html__('Clean folder range', 'media-clean-and-arrange-manager'); ?></label>
                            </div>

                            <label>
                                <span><?php echo esc_html__('Folder (YYYY/MM)', 'media-clean-and-arrange-manager'); ?></span>
                                <input type="text" id="mca_cleanup_folder">
                            </label>
                            <label>
                                <span><?php echo esc_html__('Range start (YYYY-MM)', 'media-clean-and-arrange-manager'); ?></span>
                                <input type="month" id="mca_cleanup_month_start" value="<?php echo esc_attr($month_start); ?>">
                            </label>
                            <label>
                                <span><?php echo esc_html__('Range end (YYYY-MM)', 'media-clean-and-arrange-manager'); ?></span>
                                <input type="month" id="mca_cleanup_month_end" value="<?php echo esc_attr($month_end); ?>">
                            </label>

                            <label class="mca-cleanup-checkbox">
                                <input type="checkbox" id="mca_cleanup_only_orphan" value="1" checked>
                                <?php echo esc_html__('Delete only orphan resized (only if original is missing).', 'media-clean-and-arrange-manager'); ?>
                            </label>
                        </div>

                        <div class="mca-cleanup-actions">
                            <button type="button" class="button" id="mca_cleanup_scan"><?php echo esc_html__('Scan resized', 'media-clean-and-arrange-manager'); ?></button>
                            <button type="button" class="button button-primary" id="mca_cleanup_delete" disabled><?php echo esc_html__('Delete found (batch)', 'media-clean-and-arrange-manager'); ?></button>
                            <span class="mca-cleanup-status" id="mca_cleanup_status"></span>
                        </div>
                        <div class="mca-cleanup-results" id="mca_cleanup_results" style="display:none;"></div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($tab === 'help') : ?>
                <div class="mca-card">
                    <h2><?php echo esc_html__('Before you run destructive actions', 'media-clean-and-arrange-manager'); ?></h2>
                    <div class="notice notice-warning" style="margin: 10px 0 12px 0; padding: 10px 12px;">
                        <p style="margin: 0;">
                            <strong><?php echo esc_html__('Warning:', 'media-clean-and-arrange-manager'); ?></strong>
                            <?php echo esc_html__('This plugin can delete files from your server (uploads) and permanently delete Media Library attachments. These actions are irreversible.', 'media-clean-and-arrange-manager'); ?>
                        </p>
                        <p style="margin: 8px 0 0 0;">
                            <?php echo esc_html__('Always review scan results carefully and make a full backup (database + uploads) before proceeding. If you are not sure what you are doing, do not run destructive actions.', 'media-clean-and-arrange-manager'); ?>
                        </p>
                    </div>
                    <ul class="mca-help">
                        <li><?php echo esc_html__('Always take a full backup (database + uploads).', 'media-clean-and-arrange-manager'); ?></li>
                        <li><?php echo esc_html__('Run scans first and review samples.', 'media-clean-and-arrange-manager'); ?></li>
                        <li><?php echo esc_html__('Bulk “Delete permanently” removes attachments and tries to delete all file sizes.', 'media-clean-and-arrange-manager'); ?></li>
                        <li><?php echo esc_html__('Cleanup resized removes only orphan -WxH files (keeps originals).', 'media-clean-and-arrange-manager'); ?></li>
                    </ul>
                </div>

                <div class="mca-card">
                    <h2><?php echo esc_html__('Security', 'media-clean-and-arrange-manager'); ?></h2>
                    <p><?php echo esc_html__('These options harden the tools against abuse and provide accountability.', 'media-clean-and-arrange-manager'); ?></p>

                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-top: 12px;">
                        <input type="hidden" name="action" value="mca_security_save">
                        <?php wp_nonce_field('mca_security_save', 'mca_security_nonce'); ?>

                        <p style="margin: 0 0 10px 0;">
                            <label>
                                <input type="checkbox" name="mca_audit_enabled" value="1" <?php checked($audit_enabled, true); ?>>
                                <?php echo esc_html__('Enable audit log (recommended).', 'media-clean-and-arrange-manager'); ?>
                            </label>
                        </p>

                        <p style="margin: 0 0 10px 0;">
                            <label>
                                <input type="checkbox" name="mca_audit_file_enabled" value="1" <?php checked((bool) get_option(self::OPT_AUDIT_FILE_ENABLED, 1), true); ?>>
                                <?php echo esc_html__('Write audit log to file (uploads) (recommended).', 'media-clean-and-arrange-manager'); ?>
                            </label>
                        </p>

                        <p style="margin: 0 0 10px 0;">
                            <label>
                                <input type="checkbox" name="mca_audit_wplog_enabled" value="1" <?php checked((bool) get_option(self::OPT_AUDIT_WPLOG_ENABLED, 0), true); ?>>
                                <?php echo esc_html__('Write audit log to WP/PHP error log (optional).', 'media-clean-and-arrange-manager'); ?>
                            </label>
                        </p>

                        <p style="margin: 0 0 8px 0;">
                            <label>
                                <input type="checkbox" name="mca_rate_limit_enabled" value="1" <?php checked($rate_enabled, true); ?>>
                                <?php echo esc_html__('Enable scan rate limit (recommended).', 'media-clean-and-arrange-manager'); ?>
                            </label>
                        </p>
                        <p style="margin: 0 0 12px 0;">
                            <label>
                                <?php echo esc_html__('Scan cooldown (seconds):', 'media-clean-and-arrange-manager'); ?>
                                <input type="number" name="mca_rate_limit_seconds" value="<?php echo esc_attr((string) $rate_seconds); ?>" min="0" max="300" step="1" style="width: 90px;">
                            </label>
                        </p>

                        <p style="margin: 0 0 10px 0;">
                            <label>
                                <input type="checkbox" name="mca_mask_paths" value="1" <?php checked(self::is_mask_paths_enabled(), true); ?>>
                                <?php echo esc_html__('Mask file paths in UI (recommended).', 'media-clean-and-arrange-manager'); ?>
                            </label>
                        </p>

                        <p style="margin: 0 0 12px 0;">
                            <label>
                                <input type="checkbox" name="mca_break_glass_enabled" value="1" <?php checked(self::is_break_glass_enabled(), true); ?>>
                                <?php echo esc_html__('Require typing DELETE for destructive actions (recommended).', 'media-clean-and-arrange-manager'); ?>
                            </label>
                        </p>

                        <p style="margin: 0;">
                            <button type="submit" class="button button-primary"><?php echo esc_html__('Save security settings', 'media-clean-and-arrange-manager'); ?></button>
                        </p>
                    </form>
                </div>

                <div class="mca-card">
                    <h2><?php echo esc_html__('Audit log', 'media-clean-and-arrange-manager'); ?></h2>
                    <p><?php echo esc_html__('Last actions executed via this plugin (keeps a limited history).', 'media-clean-and-arrange-manager'); ?></p>

                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin: 10px 0 12px 0;">
                        <input type="hidden" name="action" value="mca_audit_clear">
                        <?php wp_nonce_field('mca_audit_clear', 'mca_audit_clear_nonce'); ?>
                        <button type="submit" class="button button-secondary" onclick="return confirm('<?php echo esc_js(__('Clear audit log?', 'media-clean-and-arrange-manager')); ?>');">
                            <?php echo esc_html__('Clear audit log', 'media-clean-and-arrange-manager'); ?>
                        </button>
                    </form>

                    <?php if (empty($audit_log)) : ?>
                        <p><?php echo esc_html__('Audit log is empty.', 'media-clean-and-arrange-manager'); ?></p>
                    <?php else : ?>
                        <div style="overflow:auto;">
                            <table class="widefat striped">
                                <thead>
                                <tr>
                                    <th><?php echo esc_html__('Time', 'media-clean-and-arrange-manager'); ?></th>
                                    <th><?php echo esc_html__('User', 'media-clean-and-arrange-manager'); ?></th>
                                    <th><?php echo esc_html__('Action', 'media-clean-and-arrange-manager'); ?></th>
                                    <th><?php echo esc_html__('Details', 'media-clean-and-arrange-manager'); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                $shown = array_slice($audit_log, 0, 50);
                                foreach ($shown as $row) :
                                    $t = isset($row['time']) ? (string) $row['time'] : '';
                                    $u = isset($row['user']) ? (string) $row['user'] : '';
                                    $a = isset($row['action']) ? (string) $row['action'] : '';
                                    $d = isset($row['details']) ? wp_json_encode($row['details'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : '';
                                    ?>
                                    <tr>
                                        <td><?php echo esc_html($t); ?></td>
                                        <td><?php echo esc_html($u); ?></td>
                                        <td><?php echo esc_html($a); ?></td>
                                        <td><code><?php echo esc_html($d); ?></code></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if (self::ENABLE_DONATE_TAB && $tab === 'donate') : ?>
                <div class="mca-card">
                    <h2><?php echo esc_html__('Support development', 'media-clean-and-arrange-manager'); ?></h2>
                    <p>
                        <?php echo esc_html__('If this plugin helped you clean up a messy Media Library, you can support continued development with a small donation.', 'media-clean-and-arrange-manager'); ?>
                    </p>

                    <p>
                        <?php
                        $paypal_url = 'https://www.paypal.com/donate/?business=redizajn%40gmail.com&currency_code=EUR';
                        ?>
                        <a class="button button-primary" href="<?php echo esc_url($paypal_url); ?>" target="_blank" rel="noopener">
                            <?php echo esc_html__('Donate via PayPal', 'media-clean-and-arrange-manager'); ?>
                        </a>
                    </p>

                    <hr>

                    <h3><?php echo esc_html__('Legal / Disclaimer', 'media-clean-and-arrange-manager'); ?></h3>
                    <ul class="mca-help">
                        <li><?php echo esc_html__('Donations are voluntary and do not purchase support, consulting, or any guaranteed feature.', 'media-clean-and-arrange-manager'); ?></li>
                        <li><?php echo esc_html__('This software is provided “as is”, without warranty of any kind. You are responsible for running it and for keeping backups.', 'media-clean-and-arrange-manager'); ?></li>
                        <li><?php echo esc_html__('We are not affiliated with or endorsed by PayPal or WordPress.', 'media-clean-and-arrange-manager'); ?></li>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    private static function admin_url(array $args = []): string {
        $base = add_query_arg(['page' => self::SLUG], admin_url('admin.php'));
        if (!empty($args)) {
            $base = add_query_arg($args, $base);
        }
        return $base;
    }

    // Bulk actions (gallery)
    public static function handle_bulk_action(): void {
        if (!current_user_can(self::CAPABILITY)) {
            wp_die(esc_html__('Sorry, you are not allowed to delete items.', 'media-clean-and-arrange-manager'));
        }
        check_admin_referer(self::NONCE_ACTION, self::NONCE_NAME);

        $post = is_array($_POST) ? wp_unslash($_POST) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $action = isset($post['mca_action']) ? sanitize_key((string) $post['mca_action']) : '';
        $ids = isset($post['media']) ? (array) $post['media'] : [];
        $ids = array_values(array_filter(array_map('absint', $ids)));

        if ($action === '' || empty($ids)) {
            wp_safe_redirect(self::admin_url(['tab' => 'gallery', 'mca_msg' => rawurlencode(__('No items selected.', 'media-clean-and-arrange-manager'))]));
            exit;
        }

        if ($action === 'delete') {
            self::require_break_glass_or_die();
        }

        // Images only
        $ids = array_values(array_filter($ids, static function ($id) {
            $mime = get_post_mime_type($id);
            return is_string($mime) && strpos($mime, 'image/') === 0;
        }));

        $done = 0;
        foreach ($ids as $id) {
            if ($action === 'trash') {
                if (wp_trash_post($id)) $done++;
            } elseif ($action === 'restore') {
                if (wp_untrash_post($id)) $done++;
            } elseif ($action === 'detach') {
                $post = get_post($id);
                if ($post && $post->post_type === 'attachment') {
                    $r = wp_update_post(['ID' => $id, 'post_parent' => 0], true);
                    if (!is_wp_error($r)) $done++;
                }
            } elseif ($action === 'delete') {
                $deleted = wp_delete_attachment($id, true);
                if ($deleted) $done++;
            }
        }

        self::audit_log('bulk_action', [
            'action' => $action,
            'requested' => count($ids),
            'done' => $done,
        ]);

        wp_safe_redirect(self::admin_url([
            'tab' => 'gallery',
            // translators: 1: number of processed items, 2: total selected items
            'mca_msg' => rawurlencode(sprintf(__('Done: %1$d / %2$d', 'media-clean-and-arrange-manager'), $done, count($ids))),
        ]));
        exit;
    }

    public static function handle_security_save(): void {
        if (!current_user_can(self::CAPABILITY)) {
            wp_die(esc_html__('Sorry, you are not allowed to do this.', 'media-clean-and-arrange-manager'));
        }
        check_admin_referer('mca_security_save', 'mca_security_nonce');

        $audit_enabled = !empty($_POST['mca_audit_enabled']) ? 1 : 0;
        $audit_file_enabled = !empty($_POST['mca_audit_file_enabled']) ? 1 : 0;
        $audit_wplog_enabled = !empty($_POST['mca_audit_wplog_enabled']) ? 1 : 0;
        $rate_enabled = !empty($_POST['mca_rate_limit_enabled']) ? 1 : 0;
        $rate_seconds = isset($_POST['mca_rate_limit_seconds']) ? absint($_POST['mca_rate_limit_seconds']) : 5;
        $rate_seconds = min(300, max(0, $rate_seconds));
        $mask_paths = !empty($_POST['mca_mask_paths']) ? 1 : 0;
        $break_glass = !empty($_POST['mca_break_glass_enabled']) ? 1 : 0;

        update_option(self::OPT_AUDIT_ENABLED, $audit_enabled, false);
        update_option(self::OPT_AUDIT_FILE_ENABLED, $audit_file_enabled, false);
        update_option(self::OPT_AUDIT_WPLOG_ENABLED, $audit_wplog_enabled, false);
        update_option(self::OPT_RATE_LIMIT_ENABLED, $rate_enabled, false);
        update_option(self::OPT_RATE_LIMIT_SECONDS, $rate_seconds, false);
        update_option(self::OPT_MASK_PATHS, $mask_paths, false);
        update_option(self::OPT_BREAK_GLASS_ENABLED, $break_glass, false);

        self::audit_log('security_save', [
            'audit_enabled' => (int) $audit_enabled,
            'audit_file_enabled' => (int) $audit_file_enabled,
            'audit_wplog_enabled' => (int) $audit_wplog_enabled,
            'rate_limit_enabled' => (int) $rate_enabled,
            'rate_limit_seconds' => (int) $rate_seconds,
            'mask_paths' => (int) $mask_paths,
            'break_glass' => (int) $break_glass,
        ]);

        wp_safe_redirect(self::admin_url(['tab' => 'help', 'mca_msg' => rawurlencode(__('Security settings saved.', 'media-clean-and-arrange-manager'))]));
        exit;
    }

    public static function handle_audit_clear(): void {
        if (!current_user_can(self::CAPABILITY)) {
            wp_die(esc_html__('Sorry, you are not allowed to do this.', 'media-clean-and-arrange-manager'));
        }
        check_admin_referer('mca_audit_clear', 'mca_audit_clear_nonce');
        update_option(self::OPT_AUDIT_LOG, [], false);
        wp_safe_redirect(self::admin_url(['tab' => 'help', 'mca_msg' => rawurlencode(__('Audit log cleared.', 'media-clean-and-arrange-manager'))]));
        exit;
    }

    // Gallery AJAX
    public static function ajax_gallery_load(): void {
        if (!current_user_can(self::CAPABILITY)) {
            wp_send_json_error(['message' => __('Not allowed.', 'media-clean-and-arrange-manager')], 403);
        }
        check_ajax_referer(self::AJAX_NONCE_ACTION, 'nonce');

        $page = isset($_POST['page']) ? absint($_POST['page']) : 1;
        $per_page = isset($_POST['per_page']) ? absint($_POST['per_page']) : 100;
        $per_page = ($per_page > 0 && $per_page <= 200) ? $per_page : 100;
        $page = max(1, $page);

        $mode = isset($_POST['mode']) ? sanitize_key(wp_unslash($_POST['mode'])) : 'date';
        $mode = in_array($mode, ['date', 'folder'], true) ? $mode : 'date';
        $start = isset($_POST['start']) ? sanitize_text_field(wp_unslash($_POST['start'])) : '';
        $end = isset($_POST['end']) ? sanitize_text_field(wp_unslash($_POST['end'])) : '';
        $month_start = isset($_POST['month_start']) ? sanitize_text_field(wp_unslash($_POST['month_start'])) : '';
        $month_end = isset($_POST['month_end']) ? sanitize_text_field(wp_unslash($_POST['month_end'])) : '';
        $s = isset($_POST['s']) ? sanitize_text_field(wp_unslash($_POST['s'])) : '';

        $res = self::query_attachments([
            'per_page' => $per_page,
            'page' => $page,
            'mode' => $mode,
            'start' => $start,
            'end' => $end,
            'month_start' => $month_start,
            'month_end' => $month_end,
            's' => $s,
        ]);

        wp_send_json_success([
            'html' => self::render_gallery_items_html($res['items']),
            'has_more' => $res['has_more'],
            'next_page' => $page + 1,
        ]);
    }

    // Sync AJAX
    public static function ajax_sync_scan(): void {
        if (!current_user_can(self::CAPABILITY)) {
            wp_send_json_error(['message' => __('Not allowed.', 'media-clean-and-arrange-manager')], 403);
        }
        check_ajax_referer(self::SYNC_NONCE_ACTION, 'nonce');
        self::enforce_scan_rate_limit('sync_scan');

        $folder = isset($_POST['folder']) ? sanitize_text_field(wp_unslash($_POST['folder'])) : '';
        $month_start = isset($_POST['month_start']) ? sanitize_text_field(wp_unslash($_POST['month_start'])) : '';
        $month_end = isset($_POST['month_end']) ? sanitize_text_field(wp_unslash($_POST['month_end'])) : '';
        $include_resized = !empty($_POST['include_resized']);

        // Full scan by default (returns all matching items; internally scanned in batches).
        $post = is_array($_POST) ? wp_unslash($_POST) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $months = isset($post['months']) ? (array) $post['months'] : [];
        $months = array_values(array_filter(array_map('sanitize_text_field', $months)));
        $cursor = isset($post['cursor']) && is_array($post['cursor']) ? $post['cursor'] : null;

        if (empty($months)) {
            if ($folder !== '') {
                $folder = trim($folder, " \t\n\r\0\x0B/\\");
                if (!preg_match('/^(\\d{4})\\/(0[1-9]|1[0-2])$/', $folder)) {
                    wp_send_json_error(['message' => __('Folder must be in YYYY/MM format (e.g. 2017/02).', 'media-clean-and-arrange-manager')], 400);
                }
                $months = [$folder];
            } else {
                $prefixes = self::month_prefixes_between($month_start, $month_end);
                if (empty($prefixes)) {
                    wp_send_json_error(['message' => __('Range must be YYYY-MM (e.g. 2014-01 to 2020-01).', 'media-clean-and-arrange-manager')], 400);
                }
                foreach ($prefixes as $p) {
                    $months[] = trim($p, '/'); // YYYY/MM
                }
            }
        }

        foreach ($months as $m) {
            if (!preg_match('/^(\\d{4})\\/(0[1-9]|1[0-2])$/', $m)) {
                wp_send_json_error(['message' => __('Invalid month folder list.', 'media-clean-and-arrange-manager')], 400);
            }
        }

        $scan = self::scan_missing_files_all($months, $include_resized);
        $uploads = wp_upload_dir();
        $baseurl = isset($uploads['baseurl']) ? (string) $uploads['baseurl'] : '';
        $missing = array_values(array_filter(array_map('strval', $scan['missing'] ?? [])));
        $scan_id = self::create_scan_token('sync', $missing);
        self::audit_log('sync_scan', [
            'scan_id' => $scan_id,
            'months' => $months,
            'include_resized' => $include_resized ? 1 : 0,
            'total' => count($missing),
            'truncated' => !empty($scan['truncated']) ? 1 : 0,
        ]);

        $items = [];
        foreach ($missing as $rel) {
            $rel = (string) $rel;
            $items[] = [
                'rel' => $rel,
                'url' => $baseurl !== '' ? ($baseurl . '/' . ltrim($rel, '/')) : '',
            ];
        }

        wp_send_json_success([
            'months' => $months,
            'scan_id' => $scan_id,
            'items' => $items,
            'total' => count($items),
            'truncated' => !empty($scan['truncated']) ? 1 : 0,
        ]);
    }

    public static function ajax_sync_import(): void {
        if (!current_user_can(self::CAPABILITY)) {
            wp_send_json_error(['message' => __('Not allowed.', 'media-clean-and-arrange-manager')], 403);
        }
        check_ajax_referer(self::SYNC_NONCE_ACTION, 'nonce');
        self::require_break_glass_or_json_error();

        $scan_id = isset($_POST['scan_id']) ? sanitize_text_field(wp_unslash($_POST['scan_id'])) : '';
        if ($scan_id === '') {
            wp_send_json_error(['message' => __('Run the scan first.', 'media-clean-and-arrange-manager')], 400);
        }
        $scan = self::get_scan_token_data('sync', $scan_id);
        if ($scan === null || empty($scan['files']) || !is_array($scan['files'])) {
            wp_send_json_error(['message' => __('Run the scan first.', 'media-clean-and-arrange-manager')], 400);
        }
        $files = array_values(array_filter(array_map('strval', $scan['files'])));

        $offset = isset($_POST['offset']) ? absint($_POST['offset']) : 0;
        $limit = 25;
        $res = self::import_files_from_list($files, $offset, $limit);
        self::update_scan_token_stats('sync', $scan_id, [
            'imported' => (int) ($res['imported'] ?? 0),
            'skipped' => (int) ($res['skipped'] ?? 0),
        ]);

        if (!empty($res['done'])) {
            $final = self::get_scan_token_data('sync', $scan_id);
            $stats = is_array($final) && isset($final['stats']) && is_array($final['stats']) ? $final['stats'] : [];
            self::audit_log('sync_import_done', [
                'scan_id' => $scan_id,
                'imported' => (int) ($stats['imported'] ?? 0),
                'skipped' => (int) ($stats['skipped'] ?? 0),
            ]);
            self::delete_scan_token('sync', $scan_id);
        }

        wp_send_json_success([
            'imported' => $res['imported'],
            'skipped' => $res['skipped'],
            'next_offset' => $res['next_offset'],
            'done' => $res['done'],
        ]);
    }

    public static function ajax_sync_delete_file(): void {
        if (!current_user_can(self::CAPABILITY)) {
            wp_send_json_error(['message' => __('Not allowed to delete.', 'media-clean-and-arrange-manager')], 403);
        }
        check_ajax_referer(self::SYNC_NONCE_ACTION, 'nonce');
        self::require_break_glass_or_json_error();

        $scan_id = isset($_POST['scan_id']) ? sanitize_text_field(wp_unslash($_POST['scan_id'])) : '';
        if ($scan_id === '') {
            wp_send_json_error(['message' => __('Run the scan first.', 'media-clean-and-arrange-manager')], 400);
        }
        $scan = self::get_scan_token_data('sync', $scan_id);
        if ($scan === null || empty($scan['files']) || !is_array($scan['files'])) {
            wp_send_json_error(['message' => __('Run the scan first.', 'media-clean-and-arrange-manager')], 400);
        }

        $rel_raw = isset($_POST['rel']) ? sanitize_text_field(wp_unslash($_POST['rel'])) : '';
        $rel = self::normalize_rel_uploads_path($rel_raw);
        if ($rel === null) {
            wp_send_json_error(['message' => __('Invalid path.', 'media-clean-and-arrange-manager')], 400);
        }
        if (!self::is_allowed_image_relpath($rel)) {
            wp_send_json_error(['message' => __('Only image files can be deleted here.', 'media-clean-and-arrange-manager')], 400);
        }

        $scan_files = array_values(array_map('strval', $scan['files']));
        if (!in_array($rel, $scan_files, true)) {
            wp_send_json_error(['message' => __('Invalid path.', 'media-clean-and-arrange-manager')], 400);
        }

        $real_full = self::resolve_uploads_realpath($rel);
        if ($real_full === null) {
            wp_send_json_error(['message' => __('File not found.', 'media-clean-and-arrange-manager')], 404);
        }

        $ok = (bool) wp_delete_file($real_full);
        if (!$ok) {
            wp_send_json_error(['message' => __('Failed to delete file.', 'media-clean-and-arrange-manager')], 500);
        }

        // Keep server scan in sync with UI; prevent any further actions on this path.
        $scan_files = array_values(array_filter($scan_files, static fn($f) => $f !== $rel));
        self::update_scan_token_files('sync', $scan_id, $scan_files);
        self::audit_log('sync_delete_file', [
            'scan_id' => $scan_id,
            'rel' => $rel,
        ]);

        wp_send_json_success(['deleted' => 1]);
    }

    // Cleanup resized AJAX (orphan-only)
    public static function ajax_resized_scan(): void {
        if (!current_user_can(self::CAPABILITY)) {
            wp_send_json_error(['message' => __('Not allowed.', 'media-clean-and-arrange-manager')], 403);
        }
        check_ajax_referer(self::CLEANUP_NONCE_ACTION, 'nonce');
        self::enforce_scan_rate_limit('cleanup_scan');

        $folder = isset($_POST['folder']) ? sanitize_text_field(wp_unslash($_POST['folder'])) : '';
        $month_start = isset($_POST['month_start']) ? sanitize_text_field(wp_unslash($_POST['month_start'])) : '';
        $month_end = isset($_POST['month_end']) ? sanitize_text_field(wp_unslash($_POST['month_end'])) : '';
        $only_orphan = !empty($_POST['only_orphan']);

        $months = [];
        if ($folder !== '') {
            $folder = trim($folder, " \t\n\r\0\x0B/\\");
            if (!preg_match('/^(\\d{4})\\/(0[1-9]|1[0-2])$/', $folder)) {
                wp_send_json_error(['message' => __('Folder must be in YYYY/MM format (e.g. 2017/02).', 'media-clean-and-arrange-manager')], 400);
            }
            $months = [$folder];
        } else {
            $prefixes = self::month_prefixes_between($month_start, $month_end);
            if (empty($prefixes)) {
                wp_send_json_error(['message' => __('Range must be YYYY-MM (e.g. 2014-01 to 2020-01).', 'media-clean-and-arrange-manager')], 400);
            }
            foreach ($prefixes as $p) {
                $months[] = trim($p, '/');
            }
        }

        foreach ($months as $m) {
            if (!preg_match('/^(\\d{4})\\/(0[1-9]|1[0-2])$/', $m)) {
                wp_send_json_error(['message' => __('Invalid month folder list.', 'media-clean-and-arrange-manager')], 400);
            }
        }

        $scan = self::scan_resized_files_all($months, $only_orphan);

        $uploads = wp_upload_dir();
        $baseurl = isset($uploads['baseurl']) ? (string) $uploads['baseurl'] : '';
        $files = array_values(array_filter(array_map('strval', $scan['files'] ?? [])));
        $scan_id = self::create_scan_token('cleanup', $files);
        self::audit_log('cleanup_scan', [
            'scan_id' => $scan_id,
            'months' => $months,
            'only_orphan' => $only_orphan ? 1 : 0,
            'total' => count($files),
            'truncated' => !empty($scan['truncated']) ? 1 : 0,
        ]);
        $items = [];
        foreach ($files as $rel) {
            $rel = (string) $rel;
            $items[] = [
                'rel' => $rel,
                'url' => $baseurl !== '' ? ($baseurl . '/' . ltrim($rel, '/')) : '',
            ];
        }

        wp_send_json_success([
            'months' => $months,
            'scan_id' => $scan_id,
            'items' => $items,
            'only_orphan' => $only_orphan ? 1 : 0,
            'total' => count($items),
            'truncated' => !empty($scan['truncated']) ? 1 : 0,
        ]);
    }

    public static function ajax_resized_delete(): void {
        if (!current_user_can(self::CAPABILITY)) {
            wp_send_json_error(['message' => __('Not allowed to delete.', 'media-clean-and-arrange-manager')], 403);
        }
        check_ajax_referer(self::CLEANUP_NONCE_ACTION, 'nonce');
        self::require_break_glass_or_json_error();

        $scan_id = isset($_POST['scan_id']) ? sanitize_text_field(wp_unslash($_POST['scan_id'])) : '';
        if ($scan_id === '') {
            wp_send_json_error(['message' => __('Run the scan first.', 'media-clean-and-arrange-manager')], 400);
        }
        $scan = self::get_scan_token_data('cleanup', $scan_id);
        if ($scan === null || empty($scan['files']) || !is_array($scan['files'])) {
            wp_send_json_error(['message' => __('Run the scan first.', 'media-clean-and-arrange-manager')], 400);
        }
        $files = array_values(array_filter(array_map('strval', $scan['files'])));

        $offset = isset($_POST['offset']) ? absint($_POST['offset']) : 0;
        $limit = 120;

        $res = self::delete_files_from_list($files, $offset, $limit);
        self::update_scan_token_stats('cleanup', $scan_id, [
            'deleted' => (int) ($res['deleted'] ?? 0),
            'skipped' => (int) ($res['skipped'] ?? 0),
        ]);
        if (!empty($res['done'])) {
            $final = self::get_scan_token_data('cleanup', $scan_id);
            $stats = is_array($final) && isset($final['stats']) && is_array($final['stats']) ? $final['stats'] : [];
            self::audit_log('cleanup_delete_done', [
                'scan_id' => $scan_id,
                'deleted' => (int) ($stats['deleted'] ?? 0),
                'skipped' => (int) ($stats['skipped'] ?? 0),
            ]);
            self::delete_scan_token('cleanup', $scan_id);
        }
        wp_send_json_success([
            'deleted' => $res['deleted'],
            'skipped' => $res['skipped'],
            'next_offset' => $res['next_offset'],
            'done' => $res['done'],
        ]);
    }

    // Query + rendering helpers
    private static function query_attachments(array $args): array {
        $per_page = (int) ($args['per_page'] ?? 100);
        $page = (int) ($args['page'] ?? 1);
        $mode = (string) ($args['mode'] ?? 'date');
        $mode = in_array($mode, ['date', 'folder'], true) ? $mode : 'date';
        $start = (string) ($args['start'] ?? '');
        $end = (string) ($args['end'] ?? '');
        $month_start = (string) ($args['month_start'] ?? '');
        $month_end = (string) ($args['month_end'] ?? '');
        $s = (string) ($args['s'] ?? '');

        $meta_query = [];
        $date_query = [];

        if ($mode === 'date') {
            if ($start !== '' || $end !== '') {
                $dq = ['inclusive' => true, 'column' => 'post_date'];
                if ($start !== '') $dq['after'] = $start . ' 00:00:00';
                if ($end !== '') $dq['before'] = $end . ' 23:59:59';
                $date_query[] = $dq;
            }
        } else {
            $prefixes = self::month_prefixes_between($month_start, $month_end);
            if (!empty($prefixes)) {
                $meta_query = ['relation' => 'OR'];
                foreach ($prefixes as $p) {
                    $meta_query[] = [
                        'key' => '_wp_attached_file',
                        'value' => $p,
                        'compare' => 'LIKE',
                    ];
                }
            }
        }

        $query_args = [
            'post_type' => 'attachment',
            'post_status' => ['inherit', 'trash'],
            'post_mime_type' => 'image',
            'posts_per_page' => $per_page,
            'paged' => max(1, $page),
            's' => $s,
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => false,
        ];
        // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
        if (!empty($meta_query)) $query_args['meta_query'] = $meta_query;
        if (!empty($date_query)) $query_args['date_query'] = $date_query;

        $q = new WP_Query($query_args);
        $has_more = ((int) $q->max_num_pages) > $page;

        return [
            'items' => $q->posts ?: [],
            'has_more' => $has_more,
        ];
    }

    private static function render_gallery_items_html(array $items): string {
        if (empty($items)) {
            return '<div class="mca-empty">' . esc_html__('No results for the selected filters.', 'media-clean-and-arrange-manager') . '</div>';
        }

        $out = '';
        foreach ($items as $item) {
            if (!$item instanceof WP_Post) continue;
            $id = (int) $item->ID;
            $title = get_the_title($id);
            $thumb = wp_get_attachment_image($id, 'thumbnail', true, ['loading' => 'lazy']);
            $file = (string) get_post_meta($id, '_wp_attached_file', true);
            $dir = $file !== '' ? trim(str_replace('\\', '/', dirname($file)), '/') : '';
            $dir = ($dir === '' || $dir === '.') ? '/' : $dir;
            $dir_display = self::is_mask_paths_enabled() ? self::mask_folder_for_display($dir) : $dir;
            $is_trash = ($item->post_status === 'trash');

            $out .= '<div class="mca-tile" data-id="' . esc_attr((string) $id) . '">';
            $out .= '<label class="mca-tile-inner">';
            $out .= '<input class="mca-check" type="checkbox" name="media[]" value="' . esc_attr((string) $id) . '">';
            $out .= '<span class="mca-thumb">' . ($thumb ? $thumb : '<span class="mca-no-thumb">—</span>') . '</span>';
            $out .= '<span class="mca-meta">';
            $out .= '<span class="mca-title-text" title="' . esc_attr($title) . '">' . esc_html($title) . '</span>';
            $out .= '<span class="mca-folder" title="' . esc_attr($dir_display) . '">' . esc_html($dir_display) . '</span>';
            $out .= '</span>';
            if ($is_trash) {
                $out .= '<span class="mca-badge">' . esc_html__('Trash', 'media-clean-and-arrange-manager') . '</span>';
            }
            $out .= '</label>';
            $out .= '</div>';
        }
        return $out;
    }

    private static function month_prefixes_between(string $start_ym, string $end_ym): array {
        if (!preg_match('/^(\\d{4})-(0[1-9]|1[0-2])$/', $start_ym, $m1)) return [];
        if (!preg_match('/^(\\d{4})-(0[1-9]|1[0-2])$/', $end_ym, $m2)) return [];

        $start = new DateTimeImmutable($m1[1] . '-' . $m1[2] . '-01 00:00:00');
        $end = new DateTimeImmutable($m2[1] . '-' . $m2[2] . '-01 00:00:00');
        if ($end < $start) return [];

        $prefixes = [];
        $cur = $start;
        $guard = 0;
        while ($cur <= $end) {
            $prefixes[] = $cur->format('Y/m/');
            $cur = $cur->modify('+1 month');
            if (++$guard > 2400) break;
        }
        return $prefixes;
    }

    private static function scan_missing_files_in_months(array $months, array $cursor, int $limit, bool $include_resized): array {
        $uploads = wp_upload_dir();
        $base = isset($uploads['basedir']) ? (string) $uploads['basedir'] : '';
        if ($base === '' || !is_dir($base)) {
            return ['missing' => [], 'cursor' => $cursor, 'done' => true];
        }

        $month_idx = (int) ($cursor['month_idx'] ?? 0);
        $offset = (int) ($cursor['offset'] ?? 0);
        $missing = [];

        while ($month_idx < count($months) && count($missing) < $limit) {
            $month = $months[$month_idx];
            $dir = rtrim($base, '/\\') . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $month);
            if (!is_dir($dir)) {
                $month_idx++;
                $offset = 0;
                continue;
            }

            global $wpdb;
            $like = $wpdb->esc_like($month . '/') . '%';
            $cache_key = 'mca_existing_' . md5($like);
            $existing = wp_cache_get($cache_key, 'mca');
            if ($existing === false) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
                $existing = $wpdb->get_col(
                    $wpdb->prepare(
                        "SELECT meta_value FROM {$wpdb->postmeta}
                         WHERE meta_key = %s
                           AND meta_value LIKE %s",
                        '_wp_attached_file',
                        $like
                    )
                );
                wp_cache_set($cache_key, is_array($existing) ? $existing : [], 'mca', 300);
            }
            $existing_set = [];
            foreach ((array) $existing as $p) $existing_set[(string) $p] = true;

            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
            $scanned = 0;
            foreach ($it as $f) {
                if (!$f->isFile()) continue;
                $name = $f->getFilename();
                if (!$include_resized && preg_match('/-\\d+x\\d+\\.(jpe?g|png|gif|webp|avif|heic)$/i', $name)) continue;
                if (!preg_match('/\\.(jpe?g|png|gif|webp|avif|heic)$/i', $name)) continue;

                if ($scanned < $offset) { $scanned++; continue; }
                $scanned++;

                $full = (string) $f->getPathname();
                $rel = ltrim(str_replace('\\', '/', substr($full, strlen(rtrim($base, '/\\')))), '/');
                if (!isset($existing_set[$rel])) {
                    $missing[] = $rel;
                    if (count($missing) >= $limit) break;
                }
            }

            $offset = $offset + $scanned;
            if (count($missing) < $limit) { $month_idx++; $offset = 0; }
        }

        return [
            'missing' => $missing,
            'cursor' => ['month_idx' => $month_idx, 'offset' => $offset],
            'done' => $month_idx >= count($months),
        ];
    }

    private static function scan_missing_files_all(array $months, bool $include_resized): array {
        $cursor = ['month_idx' => 0, 'offset' => 0];
        $all = [];
        $cap = 20000;
        while (true) {
            $scan = self::scan_missing_files_in_months($months, $cursor, 500, $include_resized);
            $all = array_merge($all, $scan['missing']);
            $cursor = $scan['cursor'];
            if (!empty($scan['done'])) {
                break;
            }
            if (count($all) >= $cap) {
                return ['missing' => array_slice($all, 0, $cap), 'truncated' => true];
            }
        }
        return ['missing' => $all, 'truncated' => false];
    }

    private static function import_missing_files_in_months(array $months, array $cursor, int $limit, bool $include_resized): array {
        $uploads = wp_upload_dir();
        $base = isset($uploads['basedir']) ? (string) $uploads['basedir'] : '';
        if ($base === '' || !is_dir($base)) {
            return ['imported' => 0, 'cursor' => $cursor, 'done' => true];
        }

        $month_idx = (int) ($cursor['month_idx'] ?? 0);
        $offset = (int) ($cursor['offset'] ?? 0);
        $imported = 0;

        require_once ABSPATH . 'wp-admin/includes/image.php';

        while ($month_idx < count($months) && $imported < $limit) {
            $month = $months[$month_idx];
            $dir = rtrim($base, '/\\') . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $month);
            if (!is_dir($dir)) { $month_idx++; $offset = 0; continue; }

            global $wpdb;
            $like = $wpdb->esc_like($month . '/') . '%';
            $cache_key = 'mca_existing_' . md5($like);
            $existing = wp_cache_get($cache_key, 'mca');
            if ($existing === false) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
                $existing = $wpdb->get_col(
                    $wpdb->prepare(
                        "SELECT meta_value FROM {$wpdb->postmeta}
                         WHERE meta_key = %s
                           AND meta_value LIKE %s",
                        '_wp_attached_file',
                        $like
                    )
                );
                wp_cache_set($cache_key, is_array($existing) ? $existing : [], 'mca', 300);
            }
            $existing_set = [];
            foreach ((array) $existing as $p) $existing_set[(string) $p] = true;

            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
            $scanned = 0;
            foreach ($it as $f) {
                if (!$f->isFile()) continue;
                $name = $f->getFilename();
                if (!$include_resized && preg_match('/-\\d+x\\d+\\.(jpe?g|png|gif|webp|avif|heic)$/i', $name)) continue;
                if (!preg_match('/\\.(jpe?g|png|gif|webp|avif|heic)$/i', $name)) continue;

                if ($scanned < $offset) { $scanned++; continue; }
                $scanned++;

                $full = (string) $f->getPathname();
                $rel = ltrim(str_replace('\\', '/', substr($full, strlen(rtrim($base, '/\\')))), '/');
                if (isset($existing_set[$rel])) continue;

                $filetype = wp_check_filetype(basename($full), null);
                $mime = isset($filetype['type']) ? (string) $filetype['type'] : '';
                if (strpos($mime, 'image/') !== 0) continue;

                $dt = null;
                if (preg_match('/^(\\d{4})\\/(0[1-9]|1[0-2])/', $rel, $m)) {
                    $dt = $m[1] . '-' . $m[2] . '-01 12:00:00';
                }

                $title = preg_replace('/\\.[^.]+$/', '', basename($full));
                $attachment = [
                    'post_mime_type' => $mime,
                    'post_title' => sanitize_text_field($title),
                    'post_content' => '',
                    'post_status' => 'inherit',
                ];
                if ($dt) {
                    $attachment['post_date'] = $dt;
                    $attachment['post_date_gmt'] = get_gmt_from_date($dt);
                }

                $attach_id = wp_insert_attachment($attachment, $full, 0, true);
                if (is_wp_error($attach_id) || !$attach_id) continue;

                update_post_meta($attach_id, '_wp_attached_file', $rel);
                $meta = wp_generate_attachment_metadata($attach_id, $full);
                if (is_array($meta)) wp_update_attachment_metadata($attach_id, $meta);

                $imported++;
                $existing_set[$rel] = true;
                if ($imported >= $limit) break;
            }

            $offset = $offset + $scanned;
            if ($imported < $limit) { $month_idx++; $offset = 0; }
        }

        return [
            'imported' => $imported,
            'cursor' => ['month_idx' => $month_idx, 'offset' => $offset],
            'done' => $month_idx >= count($months),
        ];
    }

    private static function import_files_from_list(array $files, int $offset, int $limit): array {
        $uploads = wp_upload_dir();
        $base = isset($uploads['basedir']) ? (string) $uploads['basedir'] : '';
        if ($base === '' || !is_dir($base)) {
            return ['imported' => 0, 'skipped' => 0, 'next_offset' => $offset, 'done' => true];
        }
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $imported = 0;
        $skipped = 0;
        $end = min(count($files), $offset + $limit);

        global $wpdb;
        for ($i = $offset; $i < $end; $i++) {
            $rel = self::normalize_rel_uploads_path((string) $files[$i]);
            if ($rel === null || !self::is_allowed_image_relpath($rel)) {
                $skipped++;
                continue;
            }
            $real_full = self::resolve_uploads_realpath($rel);
            if ($real_full === null) {
                $skipped++;
                continue;
            }
            $mime = (string) (wp_check_filetype(basename($real_full), null)['type'] ?? '');
            if (strpos($mime, 'image/') !== 0) {
                $skipped++;
                continue;
            }

            // Already registered?
            $exists_cache_key = 'mca_attached_' . md5($rel);
            $exists = wp_cache_get($exists_cache_key, 'mca');
            if ($exists === false) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
                $exists = $wpdb->get_var($wpdb->prepare(
                    "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key=%s AND meta_value=%s LIMIT 1",
                    '_wp_attached_file',
                    $rel
                ));
                wp_cache_set($exists_cache_key, $exists ? (int) $exists : 0, 'mca', 600);
            }
            if ($exists) {
                $skipped++;
                continue;
            }

            $dt = null;
            if (preg_match('/^(\\d{4})\\/(0[1-9]|1[0-2])/', $rel, $m)) {
                $dt = $m[1] . '-' . $m[2] . '-01 12:00:00';
            }

            $title = preg_replace('/\\.[^.]+$/', '', basename($real_full));
            $attachment = [
                'post_mime_type' => $mime,
                'post_title' => sanitize_text_field($title),
                'post_content' => '',
                'post_status' => 'inherit',
            ];
            if ($dt) {
                $attachment['post_date'] = $dt;
                $attachment['post_date_gmt'] = get_gmt_from_date($dt);
            }

            $attach_id = wp_insert_attachment($attachment, $real_full, 0, true);
            if (is_wp_error($attach_id) || !$attach_id) {
                $skipped++;
                continue;
            }

            update_post_meta($attach_id, '_wp_attached_file', $rel);
            $meta = wp_generate_attachment_metadata($attach_id, $real_full);
            if (is_array($meta)) {
                wp_update_attachment_metadata($attach_id, $meta);
            }
            $imported++;
        }

        $next = $end;
        return [
            'imported' => $imported,
            'skipped' => $skipped,
            'next_offset' => $next,
            'done' => $next >= count($files),
        ];
    }

    private static function is_resized_filename(string $filename): bool {
        return (bool) preg_match('/-\\d+x\\d+(?:-[^.]+)?\\.(jpe?g|png|gif|webp|avif|heic)$/i', $filename);
    }

    private static function resized_stem_candidate(string $filename): ?string {
        if (!preg_match('/^(.*)-\\d+x\\d+(?:-[^.]+)?\\.(jpe?g|png|gif|webp|avif|heic)$/i', $filename, $m)) {
            return null;
        }
        return (string) $m[1];
    }

    private static function original_exists_for_stem(string $dir, string $stem): bool {
        $exts = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'heic'];
        $suffixes = ['', '-scaled', '-rotated', '-rotated-scaled', '-scaled-rotated'];
        foreach ($suffixes as $suf) {
            foreach ($exts as $ext) {
                $p = $dir . DIRECTORY_SEPARATOR . $stem . $suf . '.' . $ext;
                if (is_file($p)) return true;
            }
        }
        return false;
    }

    private static function scan_resized_files_in_months(array $months, array $cursor, int $limit, bool $only_orphan): array {
        $uploads = wp_upload_dir();
        $base = isset($uploads['basedir']) ? (string) $uploads['basedir'] : '';
        if ($base === '' || !is_dir($base)) {
            return ['files' => [], 'cursor' => $cursor, 'done' => true];
        }

        $month_idx = (int) ($cursor['month_idx'] ?? 0);
        $offset = (int) ($cursor['offset'] ?? 0);
        $files = [];

        while ($month_idx < count($months) && count($files) < $limit) {
            $month = $months[$month_idx];
            $dir = rtrim($base, '/\\') . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $month);
            if (!is_dir($dir)) { $month_idx++; $offset = 0; continue; }

            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
            $scanned = 0;
            foreach ($it as $f) {
                if (!$f->isFile()) continue;
                $name = $f->getFilename();
                if (!self::is_resized_filename($name)) continue;

                if ($scanned < $offset) { $scanned++; continue; }
                $scanned++;

                if ($only_orphan) {
                    $stem = self::resized_stem_candidate($name);
                    if (!$stem) continue;
                    if (self::original_exists_for_stem($f->getPath(), $stem)) continue;
                }

                $full = (string) $f->getPathname();
                $rel = ltrim(str_replace('\\', '/', substr($full, strlen(rtrim($base, '/\\')))), '/');
                $files[] = $rel;
                if (count($files) >= $limit) break;
            }

            $offset = $offset + $scanned;
            if (count($files) < $limit) { $month_idx++; $offset = 0; }
        }

        return [
            'files' => $files,
            'cursor' => ['month_idx' => $month_idx, 'offset' => $offset],
            'done' => $month_idx >= count($months),
        ];
    }

    private static function scan_resized_files_all(array $months, bool $only_orphan): array {
        $cursor = ['month_idx' => 0, 'offset' => 0];
        $all = [];
        $cap = 50000;
        while (true) {
            $scan = self::scan_resized_files_in_months($months, $cursor, 1000, $only_orphan);
            $all = array_merge($all, $scan['files']);
            $cursor = $scan['cursor'];
            if (!empty($scan['done'])) {
                break;
            }
            if (count($all) >= $cap) {
                return ['files' => array_slice($all, 0, $cap), 'truncated' => true];
            }
        }
        return ['files' => $all, 'truncated' => false];
    }

    private static function delete_resized_files_in_months(array $months, array $cursor, int $limit, bool $only_orphan): array {
        $uploads = wp_upload_dir();
        $base = isset($uploads['basedir']) ? (string) $uploads['basedir'] : '';
        if ($base === '' || !is_dir($base)) {
            return ['deleted' => 0, 'skipped' => 0, 'cursor' => $cursor, 'done' => true];
        }

        $month_idx = (int) ($cursor['month_idx'] ?? 0);
        $offset = (int) ($cursor['offset'] ?? 0);
        $deleted = 0;
        $skipped = 0;

        while ($month_idx < count($months) && $deleted < $limit) {
            $month = $months[$month_idx];
            $dir = rtrim($base, '/\\') . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $month);
            if (!is_dir($dir)) { $month_idx++; $offset = 0; continue; }

            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
            $scanned = 0;
            foreach ($it as $f) {
                if (!$f->isFile()) continue;
                $name = $f->getFilename();
                if (!self::is_resized_filename($name)) continue;

                if ($scanned < $offset) { $scanned++; continue; }
                $scanned++;

                if ($only_orphan) {
                    $stem = self::resized_stem_candidate($name);
                    if (!$stem) { $skipped++; continue; }
                    if (self::original_exists_for_stem($f->getPath(), $stem)) { $skipped++; continue; }
                }

                $full = (string) $f->getPathname();
                $ok = (bool) wp_delete_file($full);
                if ($ok) $deleted++; else $skipped++;
                if ($deleted >= $limit) break;
            }

            $offset = $offset + $scanned;
            if ($deleted < $limit) { $month_idx++; $offset = 0; }
        }

        return [
            'deleted' => $deleted,
            'skipped' => $skipped,
            'cursor' => ['month_idx' => $month_idx, 'offset' => $offset],
            'done' => $month_idx >= count($months),
        ];
    }

    private static function delete_files_from_list(array $files, int $offset, int $limit): array {
        $uploads = wp_upload_dir();
        $base = isset($uploads['basedir']) ? (string) $uploads['basedir'] : '';
        if ($base === '' || !is_dir($base)) {
            return ['deleted' => 0, 'skipped' => 0, 'next_offset' => $offset, 'done' => true];
        }

        $deleted = 0;
        $skipped = 0;
        $end = min(count($files), $offset + $limit);

        for ($i = $offset; $i < $end; $i++) {
            $rel = self::normalize_rel_uploads_path((string) $files[$i]);
            if ($rel === null || !self::is_allowed_image_relpath($rel)) {
                $skipped++;
                continue;
            }
            $real_full = self::resolve_uploads_realpath($rel);
            if ($real_full === null || !is_file($real_full)) {
                $skipped++;
                continue;
            }
            $ok = (bool) wp_delete_file($real_full);
            if ($ok) $deleted++; else $skipped++;
        }

        $next = $end;
        return [
            'deleted' => $deleted,
            'skipped' => $skipped,
            'next_offset' => $next,
            'done' => $next >= count($files),
        ];
    }

    /**
     * Normalize user-provided uploads-relative paths to a safe form.
     * Returns null if the path is empty, contains traversal, or is otherwise suspicious.
     */
    private static function normalize_rel_uploads_path(string $rel): ?string {
        $rel = trim($rel);
        if ($rel === '') {
            return null;
        }
        $rel = str_replace("\0", '', $rel);
        $rel = str_replace('\\', '/', $rel);
        $rel = ltrim($rel, '/');

        // Reject traversal & weird segments
        if (strpos($rel, '../') !== false || strpos($rel, '..\\') !== false) {
            return null;
        }
        $parts = array_values(array_filter(explode('/', $rel), static fn($p) => $p !== ''));
        foreach ($parts as $p) {
            if ($p === '.' || $p === '..') {
                return null;
            }
        }
        return implode('/', $parts);
    }

    private static function is_allowed_image_relpath(string $rel): bool {
        return (bool) preg_match('/\\.(jpe?g|png|gif|webp|avif|heic)$/i', $rel);
    }

    /**
     * Resolve an uploads-relative path to a real path, ensuring it stays within uploads/.
     * Returns null if it doesn't exist or resolves outside uploads (incl. symlinks/traversal).
     */
    private static function resolve_uploads_realpath(string $rel): ?string {
        $uploads = wp_upload_dir();
        $basedir = isset($uploads['basedir']) ? (string) $uploads['basedir'] : '';
        if ($basedir === '' || !is_dir($basedir)) {
            return null;
        }
        $base_real = realpath($basedir);
        if ($base_real === false) {
            return null;
        }
        $full = rtrim($basedir, '/\\') . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
        $full_real = realpath($full);
        if ($full_real === false) {
            return null;
        }
        // Ensure within base
        if (strpos($full_real, $base_real) !== 0) {
            return null;
        }
        return $full_real;
    }

    // Scan token helpers (server-side source of truth for file lists)
    private static function create_scan_token(string $type, array $files): string {
        $user_id = (int) get_current_user_id();
        $scan_id = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : (string) wp_rand();
        $key = self::scan_token_key($type, $user_id, $scan_id);
        set_transient($key, [
            'user_id' => $user_id,
            'type' => (string) $type,
            'created' => time(),
            'files' => array_values(array_filter(array_map('strval', $files))),
            'stats' => [
                'imported' => 0,
                'deleted' => 0,
                'skipped' => 0,
            ],
        ], self::SCAN_TTL_SECONDS);
        return $scan_id;
    }

    private static function get_scan_token_data(string $type, string $scan_id): ?array {
        $user_id = (int) get_current_user_id();
        $key = self::scan_token_key($type, $user_id, $scan_id);
        $data = get_transient($key);
        if (!is_array($data)) {
            return null;
        }
        if (!isset($data['user_id'], $data['type']) || (int) $data['user_id'] !== $user_id || (string) $data['type'] !== (string) $type) {
            return null;
        }
        return $data;
    }

    private static function update_scan_token_files(string $type, string $scan_id, array $files): void {
        $user_id = (int) get_current_user_id();
        $key = self::scan_token_key($type, $user_id, $scan_id);
        $data = get_transient($key);
        if (!is_array($data)) {
            return;
        }
        $data['files'] = array_values(array_filter(array_map('strval', $files)));
        set_transient($key, $data, self::SCAN_TTL_SECONDS);
    }

    private static function update_scan_token_stats(string $type, string $scan_id, array $delta): void {
        $user_id = (int) get_current_user_id();
        $key = self::scan_token_key($type, $user_id, $scan_id);
        $data = get_transient($key);
        if (!is_array($data)) {
            return;
        }
        if (!isset($data['stats']) || !is_array($data['stats'])) {
            $data['stats'] = ['imported' => 0, 'deleted' => 0, 'skipped' => 0];
        }
        foreach (['imported', 'deleted', 'skipped'] as $k) {
            if (isset($delta[$k])) {
                $data['stats'][$k] = (int) ($data['stats'][$k] ?? 0) + (int) $delta[$k];
            }
        }
        set_transient($key, $data, self::SCAN_TTL_SECONDS);
    }

    private static function delete_scan_token(string $type, string $scan_id): void {
        $user_id = (int) get_current_user_id();
        delete_transient(self::scan_token_key($type, $user_id, $scan_id));
    }

    private static function scan_token_key(string $type, int $user_id, string $scan_id): string {
        $type = sanitize_key($type);
        $scan_id = preg_replace('/[^a-zA-Z0-9\\-]/', '', $scan_id);
        if (!is_string($scan_id) || $scan_id === '') {
            $scan_id = 'x';
        }
        return 'mca_scan_' . $type . '_' . (int) $user_id . '_' . $scan_id;
    }

    private static function is_audit_enabled(): bool {
        return (bool) get_option(self::OPT_AUDIT_ENABLED, 1);
    }

    private static function is_rate_limit_enabled(): bool {
        return (bool) get_option(self::OPT_RATE_LIMIT_ENABLED, 1);
    }

    private static function rate_limit_seconds(): int {
        $v = absint((string) get_option(self::OPT_RATE_LIMIT_SECONDS, 5));
        return min(300, max(0, $v));
    }

    private static function enforce_scan_rate_limit(string $action): void {
        if (!self::is_rate_limit_enabled()) {
            return;
        }
        $seconds = self::rate_limit_seconds();
        if ($seconds <= 0) {
            return;
        }
        $user_id = (int) get_current_user_id();
        $key = 'mca_rl_' . sanitize_key($action) . '_' . $user_id;
        if (get_transient($key)) {
            wp_send_json_error([
                // translators: %d is the cooldown time in seconds
                'message' => sprintf(__('Please wait %d seconds before running another scan.', 'media-clean-and-arrange-manager'), $seconds),
            ], 429);
        }
        set_transient($key, 1, $seconds);
    }

    private static function audit_log(string $action, array $details = []): void {
        if (!self::is_audit_enabled()) {
            return;
        }
        $user = wp_get_current_user();
        $who = $user && $user->exists() ? ($user->user_login . ' (#' . (int) $user->ID . ')') : ('#' . (int) get_current_user_id());
        $entry = [
            'time' => gmdate('Y-m-d H:i:s') . ' UTC',
            'user' => $who,
            'action' => sanitize_key($action),
            'details' => $details,
        ];

        // Optional extra sinks (file + wp/php error log)
        if ((bool) get_option(self::OPT_AUDIT_WPLOG_ENABLED, 0)) {
            @error_log('[MCA] ' . wp_json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
        }
        if ((bool) get_option(self::OPT_AUDIT_FILE_ENABLED, 1)) {
            self::audit_log_write_file_line($entry);
        }

        $log = get_option(self::OPT_AUDIT_LOG, []);
        if (!is_array($log)) {
            $log = [];
        }
        array_unshift($log, $entry);
        if (count($log) > self::AUDIT_MAX_ENTRIES) {
            $log = array_slice($log, 0, self::AUDIT_MAX_ENTRIES);
        }
        update_option(self::OPT_AUDIT_LOG, $log, false);
    }

    private static function audit_log_write_file_line(array $entry): void {
        $uploads = wp_upload_dir();
        $base = isset($uploads['basedir']) ? (string) $uploads['basedir'] : '';
        if ($base === '' || !is_dir($base)) {
            return;
        }
        $dir = rtrim($base, '/\\') . DIRECTORY_SEPARATOR . 'mca-logs';
        if (!wp_mkdir_p($dir)) {
            return;
        }

        // Best-effort protection for Apache / directory listing.
        $index = $dir . DIRECTORY_SEPARATOR . 'index.php';
        if (!file_exists($index)) {
            @file_put_contents($index, "<?php\n// Silence is golden.\n"); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
        }
        $ht = $dir . DIRECTORY_SEPARATOR . '.htaccess';
        if (!file_exists($ht)) {
            @file_put_contents($ht, "Deny from all\n<FilesMatch \"\\.log$\">\nDeny from all\n</FilesMatch>\n"); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
        }

        $file = $dir . DIRECTORY_SEPARATOR . 'mca-audit.log';
        if (file_exists($file) && @filesize($file) !== false && (int) @filesize($file) > self::AUDIT_FILE_MAX_BYTES) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
            $rot = $dir . DIRECTORY_SEPARATOR . 'mca-audit.log.1';
            wp_delete_file($rot);
            @rename($file, $rot); // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
        }
        $line = wp_json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
        @file_put_contents($file, $line, FILE_APPEND); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
    }

    private static function is_mask_paths_enabled(): bool {
        return (bool) get_option(self::OPT_MASK_PATHS, 1);
    }

    private static function is_break_glass_enabled(): bool {
        return (bool) get_option(self::OPT_BREAK_GLASS_ENABLED, 1);
    }

    private static function mask_folder_for_display(string $dir): string {
        $dir = trim(str_replace('\\', '/', $dir), '/');
        if ($dir === '' || $dir === '.') {
            return '/';
        }
        // Prefer YYYY/MM if present
        if (preg_match('/^(\\d{4}\\/\\d{2})(?:\\/|$)/', $dir, $m)) {
            return (string) $m[1];
        }
        $parts = array_values(array_filter(explode('/', $dir)));
        $last = end($parts);
        return $last ? ('…/' . $last) : '…';
    }

    private static function require_break_glass_or_die(): void {
        if (!self::is_break_glass_enabled()) {
            return;
        }
        $val = isset($_POST['mca_confirm']) ? sanitize_text_field(wp_unslash($_POST['mca_confirm'])) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if (!self::break_glass_phrase_ok($val)) {
            wp_die(esc_html__('Confirmation required. Type DELETE to proceed.', 'media-clean-and-arrange-manager'));
        }
    }

    private static function require_break_glass_or_json_error(): void {
        if (!self::is_break_glass_enabled()) {
            return;
        }
        $val = isset($_POST['confirm']) ? sanitize_text_field(wp_unslash($_POST['confirm'])) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if (!self::break_glass_phrase_ok($val)) {
            wp_send_json_error(['message' => __('Confirmation required. Type DELETE to proceed.', 'media-clean-and-arrange-manager')], 400);
        }
    }

    private static function break_glass_phrase_ok(string $val): bool {
        $val = strtoupper(trim($val));
        return $val === 'DELETE';
    }

    private static function get_audit_log(): array {
        $log = get_option(self::OPT_AUDIT_LOG, []);
        return is_array($log) ? $log : [];
    }
}

MCA_Media_Clean_Arrange_Manager::init();


